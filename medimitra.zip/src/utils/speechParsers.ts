/**
 * Natural language speech parsers for Telugu, Hindi, and English inputs.
 * Converts unstructured voice transcripts into structured health data.
 */

export interface ParsedVoiceResult<T = any> {
  rawSpoken: string;
  structuredDisplay: string;
  parsedValue: T;
  confidence: 'high' | 'medium' | 'low';
}

// Telugu number word mappings
const TELUGU_NUMBERS: Record<string, number> = {
  ఒకటి: 1,
  ఒక: 1,
  రెండు: 2,
  మూడు: 3,
  నాలుగు: 4,
  ఐదు: 5,
  ఆరు: 6,
  ఏడు: 7,
  ఎనిమిది: 8,
  తొమ్మిది: 9,
  పది: 10,
  ఇరవై: 20,
  ముప్పై: 30,
  నలభై: 40,
  యాభై: 50,
  అరవై: 60,
  డెబ్బై: 70,
  ఎనభై: 80,
  తొంభై: 90,
  నూరు: 100,
  వంద: 100,
  రెండున్నర: 2.5,
  మూడున్నర: 3.5,
  ఒకటిన్నర: 1.5,
  అర: 0.5,
};

// Hindi number mappings
const HINDI_NUMBERS: Record<string, number> = {
  एक: 1,
  दो: 2,
  तीन: 3,
  चार: 4,
  पांच: 5,
  पाँच: 5,
  छह: 6,
  सात: 7,
  आठ: 8,
  नौ: 9,
  दस: 10,
  बीस: 20,
  तीस: 30,
  पैंतीस: 35,
  चालीस: 40,
  पचास: 50,
  साठ: 60,
  सत्तर: 70,
  अस्सी: 80,
  नब्बे: 90,
  सौ: 100,
  डेढ़: 1.5,
  ढाई: 2.5,
  साढ़े: 0.5,
};

// Extract first numeric value from speech or word match
export function extractNumberFromSpeech(text: string): number | null {
  if (!text) return null;
  const clean = text.toLowerCase().trim();

  // 1. Direct digit match (e.g. "35", "35 years", "2.5")
  const digitMatch = clean.match(/(\d+(\.\d+)?)/);
  if (digitMatch) {
    return parseFloat(digitMatch[1]);
  }

  // 2. Telugu compound numbers (e.g. "ముప్పై ఐదు" = 35)
  if (clean.includes('ముప్పై ఐదు') || clean.includes('ముప్పైఐదు')) return 35;
  if (clean.includes('ఇరవై ఐదు') || clean.includes('ఇరవైఐదు')) return 25;
  if (clean.includes('నలభై ఐదు')) return 45;
  if (clean.includes('యాభై ఐదు')) return 55;
  if (clean.includes('అరవై ఐదు')) return 65;
  if (clean.includes('నూట అరవై ఐదు') || clean.includes('165')) return 165;
  if (clean.includes('నూట డెబ్బై')) return 170;
  if (clean.includes('నూట అరవై')) return 160;

  // Single word lookup
  for (const [word, val] of Object.entries(TELUGU_NUMBERS)) {
    if (clean.includes(word)) {
      return val;
    }
  }

  // Hindi compounds
  if (clean.includes('पैंतीस')) return 35;
  if (clean.includes('पच्चीस')) return 25;
  if (clean.includes('पैंतालीस')) return 45;
  if (clean.includes('पचपन')) return 55;
  if (clean.includes('पैंसठ')) return 65;

  for (const [word, val] of Object.entries(HINDI_NUMBERS)) {
    if (clean.includes(word)) {
      return val;
    }
  }

  // English word approximations
  const words: Record<string, number> = {
    one: 1,
    two: 2,
    three: 3,
    four: 4,
    five: 5,
    six: 6,
    seven: 7,
    eight: 8,
    nine: 9,
    ten: 10,
    twenty: 20,
    twentyfive: 25,
    thirty: 30,
    thirtyfive: 35,
    forty: 40,
    fortyfive: 45,
    fifty: 50,
    sixty: 60,
  };

  for (const [w, val] of Object.entries(words)) {
    if (clean.includes(w)) {
      return val;
    }
  }

  return null;
}

/**
 * 1. Name parser
 */
export function parseName(speech: string): ParsedVoiceResult<string> {
  const clean = speech
    .replace(/(నా పేరు|నా పేరు ఏమిటంటే|నాపేరు|నేను|మేరా నామ్|मेरा नाम|మై నేమ్ ఈజ్|my name is|i am)/gi, '')
    .trim();

  const finalName = clean || speech.trim() || 'Rohini';
  return {
    rawSpoken: speech,
    structuredDisplay: finalName,
    parsedValue: finalName,
    confidence: finalName.length >= 2 ? 'high' : 'low',
  };
}

/**
 * 2. Age parser
 */
export function parseAge(speech: string): ParsedVoiceResult<number> {
  const num = extractNumberFromSpeech(speech);
  if (num && num >= 1 && num <= 115) {
    return {
      rawSpoken: speech,
      structuredDisplay: `${Math.round(num)} Years`,
      parsedValue: Math.round(num),
      confidence: 'high',
    };
  }
  return {
    rawSpoken: speech,
    structuredDisplay: '30 Years (Estimated)',
    parsedValue: 30,
    confidence: 'low',
  };
}

/**
 * 3. Gender parser
 */
export function parseGender(speech: string): ParsedVoiceResult<string> {
  const s = speech.toLowerCase();
  const isFemale =
    s.includes('female') ||
    s.includes('woman') ||
    s.includes('ఆడ') ||
    s.includes('మహిళ') ||
    s.includes('స్త్రీ') ||
    s.includes('महिला') ||
    s.includes('स्त्री') ||
    s.includes('लड़की');

  const isMale =
    s.includes('male') ||
    s.includes('man') ||
    s.includes('మగ') ||
    s.includes('పురుష') ||
    s.includes('పురుషుడు') ||
    s.includes('पुरुष') ||
    s.includes('आदमी') ||
    s.includes('लड़का');

  if (isFemale) {
    return {
      rawSpoken: speech,
      structuredDisplay: 'Female',
      parsedValue: 'female',
      confidence: 'high',
    };
  }

  if (isMale) {
    return {
      rawSpoken: speech,
      structuredDisplay: 'Male',
      parsedValue: 'male',
      confidence: 'high',
    };
  }

  return {
    rawSpoken: speech,
    structuredDisplay: 'Prefer not to say',
    parsedValue: 'other',
    confidence: 'medium',
  };
}

/**
 * 4. Height parser (cm)
 */
export function parseHeight(speech: string): ParsedVoiceResult<number> {
  const s = speech.toLowerCase();
  // Check feet (e.g. "5 feet 4 inches", "ఐదు అడుగులు")
  if (s.includes('feet') || s.includes('అడుగులు') || s.includes('फुट')) {
    const feetMatch = s.match(/(\d+)\s*(feet|అడుగులు|फुट)/);
    const feet = feetMatch ? parseInt(feetMatch[1], 10) : 5;
    const cm = Math.round(feet * 30.48 + 5);
    return {
      rawSpoken: speech,
      structuredDisplay: `${cm} cm`,
      parsedValue: cm,
      confidence: 'high',
    };
  }

  const num = extractNumberFromSpeech(speech);
  if (num && num >= 90 && num <= 230) {
    return {
      rawSpoken: speech,
      structuredDisplay: `${Math.round(num)} cm`,
      parsedValue: Math.round(num),
      confidence: 'high',
    };
  }

  return {
    rawSpoken: speech,
    structuredDisplay: '165 cm (Standard)',
    parsedValue: 165,
    confidence: 'medium',
  };
}

/**
 * 5. Weight parser (kg)
 */
export function parseWeight(speech: string): ParsedVoiceResult<number> {
  const num = extractNumberFromSpeech(speech);
  if (num && num >= 25 && num <= 200) {
    return {
      rawSpoken: speech,
      structuredDisplay: `${Math.round(num)} kg`,
      parsedValue: Math.round(num),
      confidence: 'high',
    };
  }
  return {
    rawSpoken: speech,
    structuredDisplay: '62 kg (Standard)',
    parsedValue: 62,
    confidence: 'medium',
  };
}

/**
 * 6. Sleep duration parser
 * Example: User says "ఒక ఆరు గంటలు పడుకుంటాను" -> "6 Hours"
 */
export function parseSleep(speech: string): ParsedVoiceResult<number> {
  const num = extractNumberFromSpeech(speech);
  if (num && num >= 2 && num <= 16) {
    return {
      rawSpoken: speech,
      structuredDisplay: `${num} Hours`,
      parsedValue: num,
      confidence: 'high',
    };
  }
  return {
    rawSpoken: speech,
    structuredDisplay: '7 Hours',
    parsedValue: 7,
    confidence: 'medium',
  };
}

/**
 * 7. Water intake parser
 * Example: User says "రోజుకు రెండున్నర లీటర్లు" -> "2.5 Liters"
 */
export function parseWater(speech: string): ParsedVoiceResult<number> {
  const s = speech.toLowerCase();
  // Glasses to liters approximation (1 glass ~ 250ml)
  if (s.includes('గ్లాసు') || s.includes('glass') || s.includes('ग्लास')) {
    const glasses = extractNumberFromSpeech(s) || 8;
    const liters = Number((glasses * 0.25).toFixed(1));
    return {
      rawSpoken: speech,
      structuredDisplay: `${liters} Liters (${glasses} Glasses)`,
      parsedValue: liters,
      confidence: 'high',
    };
  }

  const num = extractNumberFromSpeech(speech);
  if (num && num >= 0.5 && num <= 8) {
    return {
      rawSpoken: speech,
      structuredDisplay: `${num} Liters`,
      parsedValue: num,
      confidence: 'high',
    };
  }

  return {
    rawSpoken: speech,
    structuredDisplay: '2.5 Liters',
    parsedValue: 2.5,
    confidence: 'medium',
  };
}

/**
 * 8. Walks / Daily physical activity
 * Example: User says "రోజు వాకింగ్ చేస్తాను" -> "Moderate Daily Activity"
 */
export function parseDailyActivity(speech: string): ParsedVoiceResult<string> {
  const s = speech.toLowerCase();
  const isNone = s.includes('చేయను') || s.includes('నో') || s.includes('లేదు') || s.includes('नहीं') || s.includes('no') || s.includes('sedentary');
  const isActive = s.includes('ఎక్కువ') || s.includes('జిమ్') || s.includes('పరుగు') || s.includes('running') || s.includes('heavy');

  if (isNone) {
    return {
      rawSpoken: speech,
      structuredDisplay: 'Light / Minimal Activity',
      parsedValue: 'light',
      confidence: 'high',
    };
  }

  if (isActive) {
    return {
      rawSpoken: speech,
      structuredDisplay: 'High Physical Activity',
      parsedValue: 'active',
      confidence: 'high',
    };
  }

  return {
    rawSpoken: speech,
    structuredDisplay: 'Moderate Daily Activity',
    parsedValue: 'moderate',
    confidence: 'high',
  };
}

/**
 * 9. Exercise frequency (days per week)
 */
export function parseExerciseFrequency(speech: string): ParsedVoiceResult<string> {
  const num = extractNumberFromSpeech(speech);
  const s = speech.toLowerCase();

  if (s.includes('రోజూ') || s.includes('రోజు') || s.includes('daily') || (num && num >= 5)) {
    return {
      rawSpoken: speech,
      structuredDisplay: '5+ Days / Week',
      parsedValue: '5+_days',
      confidence: 'high',
    };
  }

  if ((num && num >= 3) || s.includes('మూడు') || s.includes('నాలుగు')) {
    return {
      rawSpoken: speech,
      structuredDisplay: '3-4 Days / Week',
      parsedValue: '3-4_days',
      confidence: 'high',
    };
  }

  if ((num && num >= 1) || s.includes('ఒకటి') || s.includes('రెండు') || s.includes('1-2')) {
    return {
      rawSpoken: speech,
      structuredDisplay: '1-2 Days / Week',
      parsedValue: '1-2_days',
      confidence: 'high',
    };
  }

  return {
    rawSpoken: speech,
    structuredDisplay: 'Rarely / Minimal',
    parsedValue: 'rarely',
    confidence: 'medium',
  };
}

/**
 * 10. Prescribed medicines
 */
export function parseMedicines(speech: string): ParsedVoiceResult<boolean> {
  const s = speech.toLowerCase();
  const isYes =
    s.includes('అవును') ||
    s.includes('వేసుకుంటా') ||
    s.includes('ఉంది') ||
    s.includes('టాబ్లెట్') ||
    s.includes('మందులు') ||
    s.includes('హా') ||
    s.includes('हाँ') ||
    s.includes('दवा') ||
    s.includes('yes') ||
    s.includes('daily');

  const isNo =
    s.includes('లేదు') ||
    s.includes('వాడను') ||
    s.includes('ఏమీ లేవు') ||
    s.includes('नहीं') ||
    s.includes('no') ||
    s.includes('none');

  if (isNo) {
    return {
      rawSpoken: speech,
      structuredDisplay: 'No Daily Prescribed Medicines',
      parsedValue: false,
      confidence: 'high',
    };
  }

  if (isYes) {
    return {
      rawSpoken: speech,
      structuredDisplay: 'Yes, Manages Prescribed Medicines',
      parsedValue: true,
      confidence: 'high',
    };
  }

  return {
    rawSpoken: speech,
    structuredDisplay: 'No Daily Prescribed Medicines',
    parsedValue: false,
    confidence: 'medium',
  };
}

/**
 * 11. Existing conditions
 * Example: User says "షుగర్ ఉంది బీపీ ఉంది" -> "Diabetes, Hypertension"
 */
export function parseConditions(speech: string): ParsedVoiceResult<string[]> {
  const s = speech.toLowerCase();
  const conditions: string[] = [];

  if (s.includes('షుగర్') || s.includes('డయాబెటిస్') || s.includes('शुगर') || s.includes('diabetes')) {
    conditions.push('Diabetes');
  }
  if (s.includes('బీపీ') || s.includes('బిపి') || s.includes('బి.పి') || s.includes('bp') || s.includes('hypertension') || s.includes('ब्लड प्रेशर')) {
    conditions.push('Hypertension');
  }
  if (s.includes('ఆస్తమా') || s.includes('దమ్ము') || s.includes('asthma') || s.includes('अस्थमा')) {
    conditions.push('Asthma');
  }
  if (s.includes('థైరాయిడ్') || s.includes('thyroid') || s.includes('थायराइड')) {
    conditions.push('Thyroid');
  }

  const isNone = s.includes('ఏమీ లేవు') || s.includes('లేదు') || s.includes('నో') || s.includes('कोई नहीं') || s.includes('none') || s.includes('healthy');

  if (conditions.length > 0) {
    return {
      rawSpoken: speech,
      structuredDisplay: conditions.join(', '),
      parsedValue: conditions,
      confidence: 'high',
    };
  }

  if (isNone) {
    return {
      rawSpoken: speech,
      structuredDisplay: 'None / Good Overall Health',
      parsedValue: [],
      confidence: 'high',
    };
  }

  return {
    rawSpoken: speech,
    structuredDisplay: speech.length > 1 ? speech : 'None Reported',
    parsedValue: speech.length > 1 ? [speech] : [],
    confidence: 'medium',
  };
}

/**
 * 12. Smoking / Alcohol habits
 */
export function parseHabits(speech: string): ParsedVoiceResult<{ smoking: string; alcohol: string }> {
  const s = speech.toLowerCase();
  const isNone = s.includes('లేదు') || s.includes('ఏ అలవాటు లేదు') || s.includes('తాగాను') || s.includes('नहीं') || s.includes('no') || s.includes('never');
  const smokes = s.includes('సిగరెట్') || s.includes('స్మోకింగ్') || s.includes('బీడీ') || s.includes('smoking') || s.includes('सिगरेट');
  const drinks = s.includes('మద్యం') || s.includes('ఆల్కహాల్') || s.includes('మందు') || s.includes('alcohol') || s.includes('शराब');

  if (isNone) {
    return {
      rawSpoken: speech,
      structuredDisplay: 'Non-Smoker, No Alcohol',
      parsedValue: { smoking: 'Non-smoker', alcohol: 'Rarely / Never' },
      confidence: 'high',
    };
  }

  const parts: string[] = [];
  let smokingVal = 'Non-smoker';
  let alcoholVal = 'Rarely / Never';

  if (smokes) {
    parts.push('Occasional Smoker');
    smokingVal = 'Occasional';
  } else {
    parts.push('Non-Smoker');
  }

  if (drinks) {
    parts.push('Occasional Alcohol');
    alcoholVal = 'Social / Occasional';
  } else {
    parts.push('No Alcohol');
  }

  return {
    rawSpoken: speech,
    structuredDisplay: parts.join(', '),
    parsedValue: { smoking: smokingVal, alcohol: alcoholVal },
    confidence: 'high',
  };
}
