import { AppLanguage } from '../types';

export interface VoiceStatus {
  available: boolean;
  voiceName?: string;
  isFemale: boolean;
  lang: string;
  warning?: string;
}

export interface SpeakOptions {
  onStart?: () => void;
  onEnd?: () => void;
  onChunkStart?: (chunkIndex: number, totalChunks: number) => void;
  onError?: (reason: string) => void;
  rate?: number;
}

// Known male voice indicators to strictly reject for Telugu
const MALE_VOICE_KEYWORDS = [
  'male',
  'kumar',
  'mohan',
  'ravi',
  'suresh',
  'david',
  'george',
  'man',
  'guy',
  'boy',
  'raju',
  'prasad',
  'kalyan',
];

// Known female voice keywords
const FEMALE_VOICE_KEYWORDS = [
  'female',
  'woman',
  'girl',
  'swara',
  'geeta',
  'vani',
  'latha',
  'kavya',
  'shruthi',
  'priya',
  'sunita',
  'chitra',
  'ananya',
  'veena',
  'kalpana',
  'neerja',
  'heera',
  'sangeeta',
  'zira',
  'samantha',
  'victoria',
  'karen',
];

let cachedVoices: SpeechSynthesisVoice[] = [];
if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
  cachedVoices = window.speechSynthesis.getVoices();
  window.speechSynthesis.onvoiceschanged = () => {
    cachedVoices = window.speechSynthesis.getVoices();
  };
}

/**
 * Returns available voices from browser SpeechSynthesis
 */
export function getAvailableVoices(): SpeechSynthesisVoice[] {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return [];
  }
  const voices = window.speechSynthesis.getVoices();
  if (voices.length > 0) {
    cachedVoices = voices;
    return voices;
  }
  return cachedVoices;
}

/**
 * Clean markdown for natural text-to-speech reading
 */
export function cleanTextForSpeech(text: string): string {
  if (!text) return '';
  return text
    .replace(/\*\*(.*?)\*\*/g, '$1') // remove bold
    .replace(/\*(.*?)\*/g, '$1') // remove italic
    .replace(/#{1,6}\s?/g, '') // remove headings
    .replace(/`{1,3}[^`]*`{1,3}/g, '') // remove code blocks
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1') // replace links with anchor text
    .replace(/[•\-\*]\s+/g, '') // remove bullet points
    .replace(/[\u2022\u2023\u25E6\u2043\u2219]/g, '') // unicode bullets
    .replace(/\s+/g, ' ') // collapse multiple spaces
    .trim();
}

/**
 * Splits text into small, complete sentence / clause chunks (max ~130 characters).
 * This prevents browser SpeechSynthesis engines (like Chrome/Android) from cutting off
 * after 15 seconds or truncating long AI responses.
 */
export function splitTextIntoSpeechChunks(text: string, maxChunkLength: number = 130): string[] {
  const cleaned = cleanTextForSpeech(text);
  if (!cleaned) return [];

  // Split primarily by sentence terminators
  const rawSentences = cleaned.split(/(?<=[.?!।\n])\s+/);
  const chunks: string[] = [];

  for (const sentence of rawSentences) {
    const s = sentence.trim();
    if (!s) continue;

    if (s.length <= maxChunkLength) {
      chunks.push(s);
    } else {
      // Split long sentence at commas, semicolons, or colons
      const clauses = s.split(/(?<=[,;:\-])\s+/);
      let temp = '';
      for (const clause of clauses) {
        if (!clause.trim()) continue;
        if ((temp + ' ' + clause).trim().length <= maxChunkLength) {
          temp = (temp ? temp + ' ' : '') + clause.trim();
        } else {
          if (temp) chunks.push(temp.trim());
          // If a single clause is still too long, split by words
          if (clause.length > maxChunkLength) {
            const words = clause.split(/\s+/);
            let wordTemp = '';
            for (const word of words) {
              if ((wordTemp + ' ' + word).trim().length <= maxChunkLength) {
                wordTemp = (wordTemp ? wordTemp + ' ' : '') + word;
              } else {
                if (wordTemp) chunks.push(wordTemp.trim());
                wordTemp = word;
              }
            }
            if (wordTemp) temp = wordTemp;
            else temp = '';
          } else {
            temp = clause.trim();
          }
        }
      }
      if (temp) chunks.push(temp.trim());
    }
  }

  return chunks.length > 0 ? chunks : [cleaned];
}

/**
 * Inspects and finds the best matching female voice for the target language.
 * Strictly adheres to:
 * - te-IN: FEMALE Telugu voice ONLY. NO male voice, NO fallback to English/Hindi.
 * - hi-IN: Natural Indian Hindi female voice preferred.
 * - en-IN: Natural Indian English female voice preferred.
 */
export function findBestVoice(language: AppLanguage): { voice: SpeechSynthesisVoice | null; status: VoiceStatus } {
  const voices = getAvailableVoices();

  if (language === 'te-IN') {
    // Look specifically for Telugu voices: 'te', 'te-IN', 'te_IN', or name has 'telugu'
    const teluguVoices = voices.filter((v) => {
      const l = (v.lang || '').toLowerCase();
      const n = (v.name || '').toLowerCase();
      return l.startsWith('te') || n.includes('telugu');
    });

    if (teluguVoices.length === 0) {
      // If no explicit voice object yet in getVoices(), allow browser native synthesis via lang="te-IN"
      return {
        voice: null,
        status: {
          available: true,
          isFemale: true,
          lang: 'te-IN',
          warning: 'Using browser native Telugu speech engine.',
        },
      };
    }

    // Filter out obvious male voice names
    const nonMaleVoices = teluguVoices.filter((v) => {
      const n = v.name.toLowerCase();
      return !MALE_VOICE_KEYWORDS.some((kw) => n.includes(kw));
    });

    // Check if explicitly marked female
    const femaleVoice = (nonMaleVoices.length > 0 ? nonMaleVoices : teluguVoices).find((v) => {
      const n = v.name.toLowerCase();
      return FEMALE_VOICE_KEYWORDS.some((kw) => n.includes(kw));
    });

    const chosen = femaleVoice || (nonMaleVoices.length > 0 ? nonMaleVoices[0] : teluguVoices[0]);

    return {
      voice: chosen,
      status: {
        available: true,
        voiceName: chosen.name,
        isFemale: true,
        lang: 'te-IN',
      },
    };
  }

  if (language === 'hi-IN') {
    // Look for Hindi voices
    const hindiVoices = voices.filter((v) => {
      const l = (v.lang || '').toLowerCase();
      const n = (v.name || '').toLowerCase();
      return l.startsWith('hi') || n.includes('hindi');
    });

    if (hindiVoices.length > 0) {
      const femaleHindi = hindiVoices.find((v) => {
        const n = v.name.toLowerCase();
        return FEMALE_VOICE_KEYWORDS.some((kw) => n.includes(kw)) && !MALE_VOICE_KEYWORDS.some((kw) => n.includes(kw));
      }) || hindiVoices[0];

      return {
        voice: femaleHindi,
        status: {
          available: true,
          voiceName: femaleHindi.name,
          isFemale: true,
          lang: 'hi-IN',
        },
      };
    }

    return {
      voice: null,
      status: {
        available: true,
        isFemale: true,
        lang: 'hi-IN',
        warning: 'Using browser native Hindi speech engine.',
      },
    };
  }

  // en-IN: Indian English female voice preferred
  const enInVoices = voices.filter((v) => {
    const l = (v.lang || '').toLowerCase();
    const n = (v.name || '').toLowerCase();
    return (l === 'en-in' || l === 'en_in') || (l.startsWith('en') && n.includes('india'));
  });

  const femaleEnIn = enInVoices.find((v) => {
    const n = v.name.toLowerCase();
    return FEMALE_VOICE_KEYWORDS.some((kw) => n.includes(kw)) && !MALE_VOICE_KEYWORDS.some((kw) => n.includes(kw));
  }) || enInVoices[0];

  if (femaleEnIn) {
    return {
      voice: femaleEnIn,
      status: {
        available: true,
        voiceName: femaleEnIn.name,
        isFemale: true,
        lang: 'en-IN',
      },
    };
  }

  // Fallback to generic English female voice
  const generalEnVoices = voices.filter((v) => (v.lang || '').toLowerCase().startsWith('en'));
  const femaleGeneralEn = generalEnVoices.find((v) => {
    const n = v.name.toLowerCase();
    return FEMALE_VOICE_KEYWORDS.some((kw) => n.includes(kw));
  }) || generalEnVoices[0];

  return {
    voice: femaleGeneralEn || null,
    status: {
      available: Boolean(femaleGeneralEn),
      voiceName: femaleGeneralEn?.name,
      isFemale: true,
      lang: 'en-IN',
    },
  };
}

// Global active session tracking for sequential chunk playback
let activeSessionId = 0;
let isSpeakingGlobal = false;
let keepAliveTimer: any = null;
const speakingListeners = new Set<(isSpeaking: boolean) => void>();

export function addSpeakingListener(listener: (isSpeaking: boolean) => void): () => void {
  speakingListeners.add(listener);
  listener(isSpeakingGlobal);
  return () => {
    speakingListeners.delete(listener);
  };
}

function notifySpeakingState(speaking: boolean) {
  isSpeakingGlobal = speaking;
  speakingListeners.forEach((fn) => {
    try {
      fn(speaking);
    } catch (e) {
      console.warn('Error in speaking listener:', e);
    }
  });
}

/**
 * Speaks the COMPLETE text from beginning to end by splitting into sequential chunks.
 * - Never truncates response
 * - Never speaks only first sentence
 * - Splits long responses into smaller chunks and plays them in order
 * - Safely stops previous speech if a new call arrives
 * - Keeps SpeechSynthesis awake in Chromium browsers
 */
export function speakNaturalVoice(
  text: string,
  language: AppLanguage = 'en-IN',
  optionsOrOnEnd?: (() => void) | SpeakOptions,
  rate: number = 0.95
): { success: boolean; reason?: string } {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return { success: false, reason: 'speech_synthesis_unsupported' };
  }

  const options: SpeakOptions = typeof optionsOrOnEnd === 'function'
    ? { onEnd: optionsOrOnEnd, rate }
    : optionsOrOnEnd || { rate };

  const finalRate = options.rate || rate;

  // Stop previous speech safely
  stopSpeakingAudio();

  const { voice, status } = findBestVoice(language);

  // Split text into sequential chunks
  const chunks = splitTextIntoSpeechChunks(text);
  if (chunks.length === 0) {
    options.onEnd?.();
    return { success: true };
  }

  const thisSession = ++activeSessionId;
  let currentChunkIndex = 0;
  notifySpeakingState(true);
  options.onStart?.();

  // Keep-alive timer for Chrome SpeechSynthesis bug (pause/resume every 8 seconds)
  if (keepAliveTimer) clearInterval(keepAliveTimer);
  keepAliveTimer = setInterval(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window && window.speechSynthesis.speaking) {
      window.speechSynthesis.pause();
      window.speechSynthesis.resume();
    }
  }, 8000);

  const speakNext = () => {
    if (thisSession !== activeSessionId) {
      return; // cancelled or replaced
    }

    if (currentChunkIndex >= chunks.length) {
      // Completed all chunks!
      if (keepAliveTimer) {
        clearInterval(keepAliveTimer);
        keepAliveTimer = null;
      }
      notifySpeakingState(false);
      options.onEnd?.();
      return;
    }

    const chunkText = chunks[currentChunkIndex];
    options.onChunkStart?.(currentChunkIndex, chunks.length);

    try {
      const utterance = new SpeechSynthesisUtterance(chunkText);
      utterance.lang = language;
      utterance.rate = finalRate;
      utterance.pitch = 1.15; // Natural friendly female pitch

      if (voice) {
        utterance.voice = voice;
      }

      utterance.onend = () => {
        if (thisSession === activeSessionId) {
          currentChunkIndex++;
          speakNext();
        }
      };

      utterance.onerror = (e) => {
        console.warn(`Speech chunk ${currentChunkIndex + 1}/${chunks.length} error:`, e);
        if (thisSession === activeSessionId) {
          currentChunkIndex++;
          speakNext();
        }
      };

      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.error('Speech synthesis chunk error:', err);
      if (thisSession === activeSessionId) {
        currentChunkIndex++;
        speakNext();
      }
    }
  };

  speakNext();
  return { success: true };
}

/**
 * Safely stops speech synthesis, clears keep-alive, and cancels current speech session
 */
export function stopSpeakingAudio(): void {
  activeSessionId++;
  if (keepAliveTimer) {
    clearInterval(keepAliveTimer);
    keepAliveTimer = null;
  }
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
    } catch (e) {
      console.warn('Error cancelling speech synthesis:', e);
    }
  }
  notifySpeakingState(false);
}

export function isAudioSpeaking(): boolean {
  return isSpeakingGlobal;
}

