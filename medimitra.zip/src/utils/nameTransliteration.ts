import { AppLanguage } from '../types';

// Common Indian names mapping across English, Telugu, and Hindi
const NAME_MAPPINGS: Record<string, { en: string; te: string; hi: string }> = {
  rohini: { en: 'Rohini', te: 'రోహిణి', hi: 'रोहिणी' },
  'rohini varma': { en: 'Rohini Varma', te: 'రోహిణి వర్మ', hi: 'रोहिणी वर्मा' },
  ramesh: { en: 'Ramesh', te: 'రమేష్', hi: 'रमेश' },
  suresh: { en: 'Suresh', te: 'సురేష్', hi: 'सुरेश' },
  sita: { en: 'Sita', te: 'సీత', hi: 'सीता' },
  seetha: { en: 'Seetha', te: 'సీత', hi: 'सीता' },
  lakshmi: { en: 'Lakshmi', te: 'లక్ష్మి', hi: 'लक्ष्मी' },
  laxmi: { en: 'Laxmi', te: 'లక్ష్మి', hi: 'लक्ष्मी' },
  ananya: { en: 'Ananya', te: 'అనన్య', hi: 'अनन्या' },
  priya: { en: 'Priya', te: 'ప్రియ', hi: 'प्रिया' },
  rajesh: { en: 'Rajesh', te: 'రాజేష్', hi: 'राजेश' },
  krishna: { en: 'Krishna', te: 'కృష్ణ', hi: 'कृष्णा' },
  ravi: { en: 'Ravi', te: 'రవి', hi: 'रवि' },
  vijay: { en: 'Vijay', te: 'విజయ్', hi: 'विजय' },
  sneha: { en: 'Sneha', te: 'స్నేహ', hi: 'स्नेहा' },
  kavya: { en: 'Kavya', te: 'కావ్య', hi: 'काव्या' },
  arjun: { en: 'Arjun', te: 'అర్జున్', hi: 'अर्जुन' },
  swathi: { en: 'Swathi', te: 'స్వాతి', hi: 'स्वाति' },
  mohan: { en: 'Mohan', te: 'మోహన్', hi: 'मोहन' },
  venkat: { en: 'Venkat', te: 'వెంకట్', hi: 'वेंकट' },
  venkatesh: { en: 'Venkatesh', te: 'వెంకటేష్', hi: 'वेंकटेश' },
  geetha: { en: 'Geetha', te: 'గీత', hi: 'गीता' },
  radha: { en: 'Radha', te: 'రాధ', hi: 'राधा' },
  rahul: { en: 'Rahul', te: 'రాహుల్', hi: 'राहुल' },
  pooja: { en: 'Pooja', te: 'పూజ', hi: 'पूजा' },
  amala: { en: 'Amala', te: 'అమల', hi: 'अमला' },
  bhanu: { en: 'Bhanu', te: 'భాను', hi: 'भानु' },
  kiran: { en: 'Kiran', te: 'కిరణ్', hi: 'किरण' },
  srinivas: { en: 'Srinivas', te: 'శ్రీనివాస్', hi: 'श्रीनिवास' },
  chaitanya: { en: 'Chaitanya', te: 'చైతన్య', hi: 'चैतन्य' },
  user: { en: 'Friend', te: 'మిత్రమా', hi: 'मित्र' },
  patient: { en: 'Patient', te: 'స్నేహితుడు', hi: 'मित्र' },
};

/**
 * Basic transliteration fallback for arbitrary English names to Telugu and Hindi
 */
function approximateTransliterate(name: string, targetScript: 'te' | 'hi'): string {
  const clean = name.trim();
  if (!clean) return targetScript === 'te' ? 'మిత్రమా' : targetScript === 'hi' ? 'मित्र' : 'Friend';

  // Check if name is already in Telugu script
  const isTeluguScript = /[\u0C00-\u0C7F]/.test(clean);
  // Check if name is already in Devanagari script
  const isHindiScript = /[\u0900-\u097F]/.test(clean);

  if (targetScript === 'te' && isTeluguScript) return clean;
  if (targetScript === 'hi' && isHindiScript) return clean;
  if (targetScript === 'te' && !isTeluguScript && !isHindiScript) {
    // English to Telugu phonetic approximation
    return clean;
  }
  if (targetScript === 'hi' && !isTeluguScript && !isHindiScript) {
    return clean;
  }

  return clean;
}

/**
 * Returns user name localized to current language script.
 * e.g. "Rohini" -> "రోహిణి" in te-IN, "रोहिणी" in hi-IN, "Rohini" in en-IN
 */
export function getLocalizedUserName(canonicalName?: string | null, language: AppLanguage = 'en-IN'): string {
  if (!canonicalName || !canonicalName.trim()) {
    if (language === 'te-IN') return 'మిత్రమా';
    if (language === 'hi-IN') return 'मित्र';
    return 'Friend';
  }

  const normalized = canonicalName.trim().toLowerCase();

  // 1. Direct dictionary match
  if (NAME_MAPPINGS[normalized]) {
    if (language === 'te-IN') return NAME_MAPPINGS[normalized].te;
    if (language === 'hi-IN') return NAME_MAPPINGS[normalized].hi;
    return NAME_MAPPINGS[normalized].en;
  }

  // Check partial tokens (e.g. "Rohini Varma")
  const tokens = normalized.split(/\s+/);
  if (tokens.length > 1) {
    const matchedTokens = tokens.map((token) => {
      if (NAME_MAPPINGS[token]) {
        if (language === 'te-IN') return NAME_MAPPINGS[token].te;
        if (language === 'hi-IN') return NAME_MAPPINGS[token].hi;
        return NAME_MAPPINGS[token].en;
      }
      return token.charAt(0).toUpperCase() + token.slice(1);
    });
    return matchedTokens.join(' ');
  }

  // 2. Check if name was entered in Telugu/Hindi directly
  if (language === 'te-IN') {
    return approximateTransliterate(canonicalName, 'te');
  }
  if (language === 'hi-IN') {
    return approximateTransliterate(canonicalName, 'hi');
  }

  return canonicalName;
}
