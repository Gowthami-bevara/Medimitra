import { Doctor, Hospital, UserLocationState } from '../types';

/**
 * Calculates Haversine distance in kilometers between two GPS coordinates
 */
export function calculateDistanceKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c;
  return Number(d.toFixed(1));
}

/**
 * Seed coordinates relative to base or user location
 */
export function getNearbyDoctorsWithLiveDistance(
  baseDoctors: Doctor[],
  userLoc: UserLocationState
): Doctor[] {
  // If doctors don't have explicit lat/lng, assign realistic offsets around user location
  const offsets = [
    { dLat: 0.0075, dLng: 0.0042 },
    { dLat: -0.012, dLng: 0.015 },
    { dLat: 0.018, dLng: -0.009 },
    { dLat: -0.022, dLng: -0.018 },
    { dLat: 0.009, dLng: 0.021 },
    { dLat: -0.031, dLng: 0.012 },
  ];

  const updated = baseDoctors.map((doc, idx) => {
    const offset = offsets[idx % offsets.length];
    const docLat = doc.lat ?? userLoc.lat + offset.dLat;
    const docLng = doc.lng ?? userLoc.lng + offset.dLng;
    const dist = calculateDistanceKm(userLoc.lat, userLoc.lng, docLat, docLng);

    return {
      ...doc,
      lat: docLat,
      lng: docLng,
      distanceKm: Math.max(0.3, dist),
    };
  });

  return updated.sort((a, b) => a.distanceKm - b.distanceKm);
}

export function getNearbyHospitalsWithLiveDistance(
  baseHospitals: Hospital[],
  userLoc: UserLocationState
): Hospital[] {
  const offsets = [
    { dLat: 0.014, dLng: 0.008 },
    { dLat: -0.025, dLng: 0.019 },
    { dLat: 0.032, dLng: -0.014 },
    { dLat: -0.018, dLng: -0.028 },
  ];

  const updated = baseHospitals.map((hosp, idx) => {
    const offset = offsets[idx % offsets.length];
    const hospLat = hosp.lat ?? userLoc.lat + offset.dLat;
    const hospLng = hosp.lng ?? userLoc.lng + offset.dLng;
    const dist = calculateDistanceKm(userLoc.lat, userLoc.lng, hospLat, hospLng);

    return {
      ...hosp,
      lat: hospLat,
      lng: hospLng,
      distanceKm: Math.max(0.5, dist),
    };
  });

  return updated.sort((a, b) => a.distanceKm - b.distanceKm);
}

/**
 * Format Google Maps directions query URL
 */
export function getDirectionsUrl(destName: string, destLat?: number, destLng?: number): string {
  if (destLat && destLng) {
    return `https://www.google.com/maps/dir/?api=1&destination=${destLat},${destLng}`;
  }
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(destName)}`;
}
