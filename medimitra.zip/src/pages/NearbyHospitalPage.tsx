import React, { useState } from 'react';
import {
  Building2,
  MapPin,
  Phone,
  Siren,
  Bed,
  CheckCircle2,
  Navigation,
  ShieldCheck,
  ArrowRight,
  AlertCircle,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../utils/i18n';
import { Compass } from 'lucide-react';

export const NearbyHospitalPage: React.FC = () => {
  const { hospitals, setActiveTab, dispatchEmergencyAmbulance, language, userLocation, detectUserLocation } = useApp();
  const t = TRANSLATIONS[language];

  const [directionsHospital, setDirectionsHospital] = useState<string | null>(null);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6 sm:space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white rounded-3xl p-6 sm:p-8 border border-blue-100 shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="p-1 rounded-md bg-blue-100 text-blue-800">
              <Building2 className="w-4 h-4" />
            </span>
            <span className="text-xs font-bold uppercase tracking-widest text-blue-800">
              Emergency Healthcare Centers
            </span>
          </div>
          <h1 className="font-display font-black text-2xl sm:text-3xl text-blue-950 tracking-tight">
            {t.nearbyHospitals}
          </h1>
          <p className="mt-1 text-slate-500 text-xs sm:text-sm max-w-2xl font-medium">
            Certified acute care hospitals with 24/7 emergency rooms, trauma centers, and ICU facilities connected to the regional ambulance network.
          </p>
        </div>

        {/* Location & Dispatch Buttons */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2.5">
          <button
            id="btn-hospital-location"
            onClick={() => detectUserLocation()}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-blue-50 border border-blue-200 text-blue-800 text-xs font-bold hover:bg-blue-100 transition-colors"
          >
            <Compass className="w-4 h-4 text-blue-600" />
            <span>{userLocation ? `${userLocation.area} (GPS Active)` : 'Calibrate Location'}</span>
          </button>

          <button
            id="btn-hospital-dispatch-amb"
            onClick={dispatchEmergencyAmbulance}
            className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs sm:text-sm shadow-md shadow-rose-600/25 transition-all self-start sm:self-auto"
          >
            <Siren className="w-4 h-4 animate-bounce" />
            <span>Dispatch Smart Ambulance</span>
          </button>
        </div>
      </div>

      {/* Demo Data Disclaimer Badge */}
      <div className="bg-slate-100 border border-slate-200 rounded-2xl p-4 flex items-center justify-between text-xs text-slate-600">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-slate-500" />
          <span>Regional healthcare facilities displayed with simulated live telemetry for technology demonstration.</span>
        </div>
        <span className="font-bold text-[10px] uppercase tracking-wider bg-slate-200 px-2 py-0.5 rounded-full text-slate-700">
          Demo Dataset
        </span>
      </div>

      {/* Turn by turn notification */}
      {directionsHospital && (
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-2xl flex items-center justify-between gap-4 animate-in fade-in duration-200">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center">
              <Navigation className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-blue-950">
                Navigation Route Activated to {directionsHospital}
              </div>
              <p className="text-[11px] text-blue-800">
                Emergency corridor mapped • Priority hospital ambulance gate assigned.
              </p>
            </div>
          </div>
          <button
            onClick={() => setDirectionsHospital(null)}
            className="px-3 py-1 bg-white border border-blue-300 text-blue-900 text-xs font-bold rounded-lg hover:bg-blue-100"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Hospital Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {hospitals.map((hosp) => (
          <div
            key={hosp.id}
            id={`hospital-card-${hosp.id}`}
            className="bg-white rounded-3xl border border-blue-100 p-6 shadow-xs flex flex-col justify-between hover:border-blue-300 transition-colors"
          >
            <div>
              <div className="flex items-start justify-between gap-3 mb-3">
                <div>
                  <h3 className="font-display font-bold text-base sm:text-lg text-blue-950">
                    {hosp.name}
                  </h3>
                  <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                    <span className="text-blue-700 font-bold bg-blue-50 px-2 py-0.5 rounded-md border border-blue-200">
                      {hosp.traumaLevel}
                    </span>
                    <span>•</span>
                    <strong className="text-slate-800">{hosp.distanceKm} km away</strong>
                  </div>
                </div>

                <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-rose-50 text-rose-700 border border-rose-200 shrink-0">
                  24x7 Emergency
                </span>
              </div>

              <div className="py-3 border-y border-slate-100 space-y-2 text-xs text-slate-600">
                <div className="flex items-center gap-2 text-slate-700">
                  <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
                  <span>{hosp.address}</span>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <div className="flex items-center gap-2 text-slate-800 font-semibold">
                    <Bed className="w-4 h-4 text-blue-600 shrink-0" />
                    <span>Available ICU Beds:</span>
                  </div>
                  <span className="font-display font-black text-blue-700 text-sm">
                    {hosp.icuBedsAvailable} Beds Ready
                  </span>
                </div>

                <div className="text-[11px] text-slate-500">
                  Ambulance Helpline: <strong className="text-slate-700">{hosp.ambulanceContact}</strong>
                </div>
              </div>
            </div>

            <div className="mt-5 pt-3 flex items-center gap-2">
              <a
                href={`tel:${hosp.emergencyHelpline.replace(/[^0-9+]/g, '')}`}
                className="flex-1 py-2.5 px-3 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors border border-rose-200"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call Emergency Desk</span>
              </a>

              <button
                id={`btn-hospital-dir-${hosp.id}`}
                onClick={() => setDirectionsHospital(hosp.name)}
                className="py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-xs"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Directions</span>
              </button>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
