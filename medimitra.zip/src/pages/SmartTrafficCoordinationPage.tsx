import React from 'react';
import {
  Siren,
  Play,
  RotateCcw,
  Zap,
  Clock,
  Radio,
  MapPin,
  Building2,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  FastForward,
  Navigation,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../utils/i18n';

export const SmartTrafficCoordinationPage: React.FC = () => {
  const {
    ambulanceSim,
    startAmbulanceSimulation,
    resetAmbulanceSimulation,
    triggerSignalPreemption,
    language,
  } = useApp();

  const t = TRANSLATIONS[language];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'idle':
        return <span className="bg-slate-100 text-slate-700 border border-slate-200 px-3 py-1 rounded-full text-xs font-bold">Ready for Simulation</span>;
      case 'dispatched':
        return <span className="bg-amber-100 text-amber-900 border border-amber-300 px-3 py-1 rounded-full text-xs font-bold animate-pulse">Ambulance Dispatched</span>;
      case 'en_route':
        return <span className="bg-blue-100 text-blue-900 border border-blue-300 px-3 py-1 rounded-full text-xs font-bold">En Route to Patient</span>;
      case 'preempting':
        return <span className="bg-violet-100 text-violet-900 border border-violet-300 px-3 py-1 rounded-full text-xs font-bold animate-pulse">Signal Preempting...</span>;
      case 'green_wave_active':
        return <span className="bg-emerald-100 text-emerald-900 border border-emerald-300 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />Green Wave Active</span>;
      case 'arrived':
        return <span className="bg-emerald-600 text-white px-3 py-1 rounded-full text-xs font-bold">Patient Destination Arrived</span>;
      default:
        return null;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6 sm:space-y-8">
      
      {/* Header with Expo Tag and Controls */}
      <div className="bg-blue-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-blue-900">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-3 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30 text-[11px] font-black uppercase tracking-wider">
                Technology Exhibition Showcase
              </span>
              <span className="text-xs text-blue-200/70 font-semibold">
                Simulated ITS & Telematics
              </span>
            </div>
            <h1 className="font-display font-black text-2xl sm:text-3xl text-white tracking-tight flex items-center gap-3">
              <Siren className="w-7 h-7 text-rose-500 animate-bounce" />
              <span>{t.smartTrafficCoordination}</span>
            </h1>
            <p className="text-blue-100/80 text-xs sm:text-sm max-w-2xl font-medium">
              Demonstrates intelligent signal preemption, vehicle-to-infrastructure (V2I) communication, and automated Green Corridor formation for emergency response.
            </p>
          </div>

          {/* Interactive Simulation Action Controls */}
          <div className="flex flex-wrap items-center gap-2.5">
            {ambulanceSim.status === 'idle' || ambulanceSim.status === 'arrived' ? (
              <button
                id="btn-start-sim"
                onClick={startAmbulanceSimulation}
                className="px-5 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-display font-extrabold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-blue-600/30 transition-transform active:scale-95"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>Start Emergency Demo</span>
              </button>
            ) : (
              <button
                id="btn-preempt-sim"
                onClick={triggerSignalPreemption}
                className="px-4 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-indigo-600/25 transition-transform active:scale-95 animate-pulse"
              >
                <Zap className="w-4 h-4" />
                <span>Trigger Green Wave</span>
              </button>
            )}

            <button
              id="btn-reset-sim"
              onClick={resetAmbulanceSimulation}
              className="px-4 py-3 rounded-2xl bg-blue-900/60 hover:bg-blue-900 text-blue-200 font-bold text-xs sm:text-sm flex items-center gap-2 border border-blue-800 transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Reset</span>
            </button>
          </div>
        </div>
      </div>

      {/* Prominent Demonstration Notice */}
      <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex items-center justify-between text-xs text-blue-950">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-blue-700 shrink-0" />
          <span>
            <strong>Simulation Mode:</strong> Traffic lights and emergency vehicle telemetry are coordinated in real-time to demonstrate urban emergency response reduction by 40–55%.
          </span>
        </div>
        <span className="font-bold text-[10px] uppercase bg-blue-200 text-blue-900 px-2 py-0.5 rounded-md">
          Live Algorithm
        </span>
      </div>

      {/* Telemetry Dashboard: ETA, Speed, Corridor Length */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl border border-blue-100 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Ambulance Status</span>
            <Radio className="w-4 h-4 text-rose-500 animate-pulse" />
          </div>
          <div className="mt-1">
            {getStatusBadge(ambulanceSim.status)}
          </div>
          <div className="text-[11px] text-slate-400 mt-2 font-mono">
            ID: {ambulanceSim.vehicleId}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-blue-100 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Estimated Arrival (ETA)</span>
            <Clock className="w-4 h-4 text-blue-600" />
          </div>
          <div className="font-display font-black text-2xl sm:text-3xl text-blue-950 mt-1">
            {ambulanceSim.etaMinutes > 0 ? `${ambulanceSim.etaMinutes} mins` : 'Arrived'}
          </div>
          <div className="text-[11px] text-blue-700 font-semibold mt-1">
            {ambulanceSim.greenWaveActive ? '✓ Time saved: 5.4 mins' : 'Calculating transit...'}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-blue-100 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Speed & Progress</span>
            <FastForward className="w-4 h-4 text-blue-500" />
          </div>
          <div className="font-display font-black text-2xl sm:text-3xl text-blue-950 mt-1">
            {ambulanceSim.speedKmH} <span className="text-sm font-semibold text-slate-500">km/h</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Progress: {ambulanceSim.progressPercentage}%
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-blue-100 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Destination Facility</span>
            <Building2 className="w-4 h-4 text-blue-600" />
          </div>
          <div className="font-display font-bold text-sm text-blue-950 mt-1 truncate">
            {ambulanceSim.destinationHospital}
          </div>
          <div className="text-[11px] text-blue-700 font-bold mt-1">
            Resuscitation Bay Cleared
          </div>
        </div>
      </div>

      {/* Interactive Corridor & Traffic Signals Map Visualizer */}
      <div className="bg-white rounded-3xl border border-blue-100 p-6 sm:p-8 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="font-display font-bold text-lg sm:text-xl text-blue-950 flex items-center gap-2">
              <Navigation className="w-5 h-5 text-blue-600" />
              <span>Smart Emergency Corridor (2.4 km)</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Real-time V2I sensor coordination across designated civic traffic junctions.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs font-bold text-slate-500">Signal Preemption:</span>
            <span className={`px-2.5 py-1 rounded-full text-xs font-black uppercase ${
              ambulanceSim.greenWaveActive
                ? 'bg-blue-100 text-blue-800 border border-blue-300'
                : 'bg-slate-100 text-slate-600 border border-slate-200'
            }`}>
              {ambulanceSim.greenWaveActive ? '🟢 Green Wave Online' : '⚪ Standard Cycle'}
            </span>
          </div>
        </div>

        {/* Visual Route Corridor Track with Moving Ambulance */}
        <div className="relative py-8 px-4 bg-slate-900 rounded-3xl overflow-hidden border border-slate-800">
          
          {/* Road Surface */}
          <div className="relative h-20 flex items-center">
            <div className="absolute inset-x-0 h-10 bg-slate-800 rounded-xl border-y border-dashed border-slate-600"></div>

            {/* Road center line */}
            <div className="absolute inset-x-0 h-0.5 border-t-2 border-dashed border-amber-400/80"></div>

            {/* Origin & Destination Nodes */}
            <div className="absolute left-2 -top-6 flex flex-col items-center">
              <div className="w-8 h-8 rounded-full bg-slate-700 text-white flex items-center justify-center border-2 border-slate-500 text-xs font-bold">
                <MapPin className="w-4 h-4" />
              </div>
              <span className="text-[10px] text-slate-400 font-bold mt-1">Incident Site</span>
            </div>

            <div className="absolute right-2 -top-6 flex flex-col items-center">
              <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center border-2 border-emerald-400 text-xs font-bold shadow-lg shadow-emerald-600/50">
                <Building2 className="w-4 h-4" />
              </div>
              <span className="text-[10px] text-emerald-400 font-bold mt-1">Trauma Bay</span>
            </div>

            {/* Animated Ambulance Icon traversing the road */}
            <div
              className="absolute transition-all duration-700 ease-linear transform -translate-x-1/2 z-10"
              style={{ left: `${Math.max(5, Math.min(95, ambulanceSim.progressPercentage))}%` }}
            >
              <div className="relative flex flex-col items-center">
                <div className="w-12 h-12 rounded-2xl bg-rose-600 text-white flex items-center justify-center shadow-xl shadow-rose-600/60 border-2 border-white animate-pulse">
                  <Siren className="w-6 h-6 animate-spin" />
                </div>
                <div className="mt-1 px-2 py-0.5 rounded-full bg-rose-950 text-white text-[10px] font-black uppercase tracking-wider whitespace-nowrap border border-rose-500">
                  ALS-108 ({ambulanceSim.speedKmH} km/h)
                </div>
              </div>
            </div>
          </div>

          {/* Intersections and Traffic Light status along corridor */}
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
            {ambulanceSim.intersections.map((signal, idx) => (
              <div
                key={signal.id}
                id={`signal-card-${signal.id}`}
                className={`p-4 rounded-2xl border transition-all ${
                  signal.preempted
                    ? 'bg-emerald-950/40 border-emerald-500 text-white shadow-md shadow-emerald-500/10'
                    : 'bg-slate-800/80 border-slate-700 text-slate-300'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-slate-700 text-slate-300 flex items-center justify-center font-bold text-[10px]">
                      {idx + 1}
                    </span>
                    <span className="font-bold text-xs text-white">
                      {signal.name}
                    </span>
                  </div>

                  {/* 3-Color Traffic Light Housing */}
                  <div className="flex items-center gap-1.5 p-1 bg-slate-950 rounded-lg border border-slate-700">
                    <div
                      className={`w-3.5 h-3.5 rounded-full transition-all ${
                        signal.state === 'RED'
                          ? 'bg-rose-500 shadow-md shadow-rose-500 ring-2 ring-rose-300/30'
                          : 'bg-rose-950 opacity-40'
                      }`}
                    />
                    <div
                      className={`w-3.5 h-3.5 rounded-full transition-all ${
                        signal.state === 'YELLOW'
                          ? 'bg-amber-400 shadow-md shadow-amber-400 ring-2 ring-amber-300/30'
                          : 'bg-amber-950 opacity-40'
                      }`}
                    />
                    <div
                      className={`w-3.5 h-3.5 rounded-full transition-all ${
                        signal.state === 'GREEN'
                          ? 'bg-emerald-400 shadow-md shadow-emerald-400 ring-2 ring-emerald-300/30 animate-pulse'
                          : 'bg-emerald-950 opacity-40'
                      }`}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-700/60">
                  <span className="text-slate-400">
                    {signal.preempted ? 'Preempted for Ambulance' : 'Standard Timer Mode'}
                  </span>
                  <span className="font-bold text-xs">
                    {signal.state === 'GREEN' ? (
                      <span className="text-emerald-400">Green Wave Active</span>
                    ) : (
                      <span className="text-rose-400">Cross-traffic Red</span>
                    )}
                  </span>
                </div>
              </div>
            ))}
          </div>

        </div>

        {/* Real-time Telemetry Logs Stream */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-display font-bold text-sm text-slate-900 flex items-center gap-2">
              <Radio className="w-4 h-4 text-emerald-600" />
              <span>Live Traffic Coordination & Telematics Log</span>
            </h3>
            <span className="text-xs text-slate-400 font-mono">
              Sensors: Active 10Hz
            </span>
          </div>

          <div className="bg-slate-950 rounded-2xl p-4 font-mono text-xs text-slate-300 max-h-48 overflow-y-auto space-y-1.5 border border-slate-800">
            {ambulanceSim.logs.map((log, index) => (
              <div key={index} className="flex items-start gap-2 leading-relaxed">
                <span className="text-slate-500 select-none">›</span>
                <span className={log.includes('GREEN WAVE') || log.includes('Preempted') ? 'text-emerald-400 font-bold' : ''}>
                  {log}
                </span>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
