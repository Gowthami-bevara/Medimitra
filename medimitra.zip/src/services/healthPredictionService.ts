import {
  HealthProfile,
  DailyHealthLog,
  MedicineItem,
  SymptomReport,
  HealthPredictionResult,
  CategoryScore
} from '../types';

export class HealthPredictionService {
  /**
   * Evaluates overall wellness score (0-100) and category scores based strictly
   * on actual user health profile data and daily tracked wellness metrics.
   */
  public static calculatePrediction(
    profile: HealthProfile | null,
    todayLog: DailyHealthLog | null,
    historyLogs: DailyHealthLog[] = [],
    medicines: MedicineItem[] = [],
    recentSymptoms: SymptomReport[] = []
  ): HealthPredictionResult {
    let availableCategoryCount = 0;
    let categorySum = 0;

    // 1. Sleep Scoring
    const sleepScore = this.evaluateSleep(profile, todayLog, historyLogs);
    if (sleepScore.score !== null) {
      categorySum += sleepScore.score;
      availableCategoryCount++;
    }

    // 2. Hydration Scoring
    const hydrationScore = this.evaluateHydration(profile, todayLog, historyLogs);
    if (hydrationScore.score !== null) {
      categorySum += hydrationScore.score;
      availableCategoryCount++;
    }

    // 3. Physical Activity
    const activityScore = this.evaluateActivity(profile, todayLog, historyLogs);
    if (activityScore.score !== null) {
      categorySum += activityScore.score;
      availableCategoryCount++;
    }

    // 4. Daily Steps
    const stepsScore = this.evaluateSteps(profile, todayLog, historyLogs);
    if (stepsScore.score !== null) {
      categorySum += stepsScore.score;
      availableCategoryCount++;
    }

    // 5. Exercise Consistency
    const exerciseScore = this.evaluateExerciseConsistency(profile, historyLogs);
    if (exerciseScore.score !== null) {
      categorySum += exerciseScore.score;
      availableCategoryCount++;
    }

    // 6. Mood
    const moodScore = this.evaluateMood(profile, todayLog, historyLogs);
    if (moodScore.score !== null) {
      categorySum += moodScore.score;
      availableCategoryCount++;
    }

    // 7. Stress
    const stressScore = this.evaluateStress(profile, todayLog, historyLogs);
    if (stressScore.score !== null) {
      categorySum += stressScore.score;
      availableCategoryCount++;
    }

    // 8. Mental Wellness (Combined Mood stability + Stress resilience)
    const mentalWellnessScore = this.evaluateMentalWellness(moodScore.score, stressScore.score);
    if (mentalWellnessScore.score !== null) {
      categorySum += mentalWellnessScore.score;
      availableCategoryCount++;
    }

    // 9. Medication Adherence
    const medicationScore = this.evaluateMedicationAdherence(profile, medicines);
    if (medicationScore.score !== null) {
      categorySum += medicationScore.score;
      availableCategoryCount++;
    }

    // 10. Nutrition & Lifestyle
    const nutritionScore = this.evaluateNutritionLifestyle(profile, todayLog, historyLogs);
    if (nutritionScore.score !== null) {
      categorySum += nutritionScore.score;
      availableCategoryCount++;
    }

    // 11. General Wellness Consistency
    const consistencyScore = this.evaluateGeneralConsistency(historyLogs);
    if (consistencyScore.score !== null) {
      categorySum += consistencyScore.score;
      availableCategoryCount++;
    }

    // Overall Score
    const overallScore = availableCategoryCount > 0
      ? Math.round(categorySum / availableCategoryCount)
      : 0;

    let status: 'Good' | 'Needs Attention' | 'High Attention' = 'Needs Attention';
    if (overallScore >= 75) {
      status = 'Good';
    } else if (overallScore >= 50) {
      status = 'Needs Attention';
    } else {
      status = 'High Attention';
    }

    const completenessPercentage = Math.round((availableCategoryCount / 11) * 100);

    // Dynamic positive and attention insights
    const { positiveInsights, areasNeedingAttention, personalizedSuggestions, trends } =
      this.generateInsights(
        profile,
        todayLog,
        historyLogs,
        medicines,
        recentSymptoms,
        {
          sleep: sleepScore,
          hydration: hydrationScore,
          physicalActivity: activityScore,
          dailySteps: stepsScore,
          exerciseConsistency: exerciseScore,
          mood: moodScore,
          stress: stressScore,
          mentalWellness: mentalWellnessScore,
          medicationAdherence: medicationScore,
          nutritionLifestyle: nutritionScore,
          generalWellnessConsistency: consistencyScore,
        }
      );

    return {
      overallScore,
      status,
      completenessPercentage,
      evaluatedAt: new Date().toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }),
      categories: {
        sleep: sleepScore,
        hydration: hydrationScore,
        physicalActivity: activityScore,
        dailySteps: stepsScore,
        exerciseConsistency: exerciseScore,
        mood: moodScore,
        stress: stressScore,
        mentalWellness: mentalWellnessScore,
        medicationAdherence: medicationScore,
        nutritionLifestyle: nutritionScore,
        generalWellnessConsistency: consistencyScore,
      },
      positiveInsights,
      areasNeedingAttention,
      personalizedSuggestions,
      trends,
    };
  }

  private static evaluateSleep(
    profile: HealthProfile | null,
    today: DailyHealthLog | null,
    history: DailyHealthLog[]
  ): CategoryScore {
    const sleepHours = today?.sleepDuration ?? profile?.typicalSleep ?? null;
    if (sleepHours === null) {
      return {
        score: null,
        status: 'Not enough data',
        label: 'Sleep',
        explanation: 'Sleep duration has not been logged yet.'
      };
    }

    let score = 50;
    if (sleepHours >= 7 && sleepHours <= 9) {
      score = 90;
    } else if (sleepHours >= 6 && sleepHours < 7) {
      score = 75;
    } else if (sleepHours > 9 && sleepHours <= 10) {
      score = 70;
    } else if (sleepHours >= 5 && sleepHours < 6) {
      score = 55;
    } else {
      score = 40;
    }

    if (today?.sleepQuality === 'excellent') score = Math.min(100, score + 10);
    else if (today?.sleepQuality === 'poor') score = Math.max(20, score - 15);

    return {
      score,
      status: score >= 75 ? 'Good' : score >= 50 ? 'Needs Attention' : 'High Attention',
      label: 'Sleep Health',
      explanation: `${sleepHours} hrs logged. Quality: ${today?.sleepQuality || 'standard'}. Optimal range is 7–9 hrs.`
    };
  }

  private static evaluateHydration(
    profile: HealthProfile | null,
    today: DailyHealthLog | null,
    _history: DailyHealthLog[]
  ): CategoryScore {
    const waterLiters = today?.waterIntakeLiters ?? profile?.typicalWater ?? null;
    if (waterLiters === null) {
      return {
        score: null,
        status: 'Not enough data',
        label: 'Hydration',
        explanation: 'Daily water intake has not been recorded.'
      };
    }

    let score = 50;
    if (waterLiters >= 2.5 && waterLiters <= 3.5) {
      score = 92;
    } else if (waterLiters >= 2.0 && waterLiters < 2.5) {
      score = 80;
    } else if (waterLiters >= 1.5 && waterLiters < 2.0) {
      score = 62;
    } else if (waterLiters >= 1.0 && waterLiters < 1.5) {
      score = 45;
    } else {
      score = 30;
    }

    return {
      score,
      status: score >= 75 ? 'Good' : score >= 50 ? 'Needs Attention' : 'High Attention',
      label: 'Hydration',
      explanation: `${waterLiters.toFixed(1)}L water consumed. Target guideline is 2.5–3.0L.`
    };
  }

  private static evaluateActivity(
    profile: HealthProfile | null,
    today: DailyHealthLog | null,
    _history: DailyHealthLog[]
  ): CategoryScore {
    const activeMins = today?.activeMinutes ?? null;
    const profileLevel = profile?.physicalActivity ?? null;

    if (activeMins === null && !profileLevel) {
      return {
        score: null,
        status: 'Not enough data',
        label: 'Physical Activity',
        explanation: 'Physical activity has not been recorded.'
      };
    }

    let score = 60;
    if (activeMins !== null) {
      if (activeMins >= 45) score = 94;
      else if (activeMins >= 30) score = 84;
      else if (activeMins >= 15) score = 68;
      else score = 48;
    } else if (profileLevel) {
      if (profileLevel === 'very_active' || profileLevel === 'active') score = 88;
      else if (profileLevel === 'moderate') score = 75;
      else if (profileLevel === 'light') score = 60;
      else score = 45;
    }

    return {
      score,
      status: score >= 75 ? 'Good' : score >= 50 ? 'Needs Attention' : 'High Attention',
      label: 'Physical Activity',
      explanation: activeMins !== null
        ? `${activeMins} active minutes logged today.`
        : `Baseline activity rating: ${profileLevel}.`
    };
  }

  private static evaluateSteps(
    profile: HealthProfile | null,
    today: DailyHealthLog | null,
    _history: DailyHealthLog[]
  ): CategoryScore {
    const steps = today?.steps ?? profile?.averageSteps ?? null;
    if (steps === null) {
      return {
        score: null,
        status: 'Not enough data',
        label: 'Daily Steps',
        explanation: 'Steps count has not been recorded.'
      };
    }

    let score = 50;
    if (steps >= 10000) score = 96;
    else if (steps >= 7500) score = 85;
    else if (steps >= 5000) score = 70;
    else if (steps >= 3000) score = 55;
    else score = 40;

    return {
      score,
      status: score >= 75 ? 'Good' : score >= 50 ? 'Needs Attention' : 'High Attention',
      label: 'Daily Steps',
      explanation: `${steps.toLocaleString()} steps tracked. Target benchmark is 7,500–10,000 steps.`
    };
  }

  private static evaluateExerciseConsistency(
    profile: HealthProfile | null,
    history: DailyHealthLog[]
  ): CategoryScore {
    const profileFreq = profile?.exerciseFrequency ?? null;
    const daysLogged = history.length;
    const exercisedDays = history.filter(h => h.exerciseLogged).length;

    if (!profileFreq && daysLogged === 0) {
      return {
        score: null,
        status: 'Not enough data',
        label: 'Exercise Consistency',
        explanation: 'Exercise frequency has not been reported.'
      };
    }

    let score = 65;
    if (daysLogged >= 3) {
      const ratio = exercisedDays / daysLogged;
      if (ratio >= 0.7) score = 92;
      else if (ratio >= 0.4) score = 78;
      else if (ratio >= 0.2) score = 60;
      else score = 45;
    } else if (profileFreq) {
      if (profileFreq === '5+_days') score = 90;
      else if (profileFreq === '3-4_days') score = 82;
      else if (profileFreq === '1-2_days') score = 65;
      else score = 45;
    }

    return {
      score,
      status: score >= 75 ? 'Good' : score >= 50 ? 'Needs Attention' : 'High Attention',
      label: 'Exercise Consistency',
      explanation: profileFreq ? `Routine target: ${profileFreq.replace('_', ' ')}` : `${exercisedDays} workout days logged.`
    };
  }

  private static evaluateMood(
    profile: HealthProfile | null,
    today: DailyHealthLog | null,
    _history: DailyHealthLog[]
  ): CategoryScore {
    const mood = today?.mood ?? profile?.currentMood ?? null;
    if (!mood) {
      return {
        score: null,
        status: 'Not enough data',
        label: 'Mood Balance',
        explanation: 'Current emotional state has not been logged.'
      };
    }

    const moodScores: Record<string, number> = {
      great: 95,
      good: 85,
      neutral: 70,
      low: 45,
      anxious: 40,
      stressed: 38
    };

    const score = moodScores[mood] || 65;

    return {
      score,
      status: score >= 75 ? 'Good' : score >= 50 ? 'Needs Attention' : 'High Attention',
      label: 'Mood Balance',
      explanation: `Current logged mood is "${mood}".`
    };
  }

  private static evaluateStress(
    profile: HealthProfile | null,
    today: DailyHealthLog | null,
    _history: DailyHealthLog[]
  ): CategoryScore {
    const stressVal = today?.stressLevel ?? null;
    const profileStress = profile?.typicalStress ?? null;

    if (stressVal === null && !profileStress) {
      return {
        score: null,
        status: 'Not enough data',
        label: 'Stress Management',
        explanation: 'Stress indicators have not been logged.'
      };
    }

    let score = 65;
    if (stressVal !== null) {
      // 1 (very low stress) to 10 (extreme stress)
      score = Math.max(10, Math.min(100, Math.round(100 - (stressVal - 1) * 9.5)));
    } else if (profileStress) {
      if (profileStress === 'low') score = 90;
      else if (profileStress === 'moderate') score = 70;
      else score = 42;
    }

    return {
      score,
      status: score >= 75 ? 'Good' : score >= 50 ? 'Needs Attention' : 'High Attention',
      label: 'Stress Resilience',
      explanation: stressVal !== null
        ? `Daily stress reported at ${stressVal}/10.`
        : `Baseline stress frequency: ${profileStress}.`
    };
  }

  private static evaluateMentalWellness(
    moodScore: number | null,
    stressScore: number | null
  ): CategoryScore {
    if (moodScore === null && stressScore === null) {
      return {
        score: null,
        status: 'Not enough data',
        label: 'Mental Wellness',
        explanation: 'Mental wellness markers require mood or stress inputs.'
      };
    }

    const count = (moodScore !== null ? 1 : 0) + (stressScore !== null ? 1 : 0);
    const score = Math.round(((moodScore || 0) + (stressScore || 0)) / count);

    return {
      score,
      status: score >= 75 ? 'Good' : score >= 50 ? 'Needs Attention' : 'High Attention',
      label: 'Mental Wellness',
      explanation: `Combined assessment of mood balance and stress adaptability.`
    };
  }

  private static evaluateMedicationAdherence(
    profile: HealthProfile | null,
    medicines: MedicineItem[]
  ): CategoryScore {
    const managesMeds = profile?.managesPrescribedMedicines;
    if (managesMeds === false || (!managesMeds && medicines.length === 0)) {
      return {
        score: 95,
        status: 'Good',
        label: 'Medication Adherence',
        explanation: 'No prescribed medications recorded or managed.'
      };
    }

    if (medicines.length === 0) {
      return {
        score: null,
        status: 'Not enough data',
        label: 'Medication Adherence',
        explanation: 'Prescription tracking indicated in profile, but no active medicines listed.'
      };
    }

    const total = medicines.length;
    const taken = medicines.filter(m => m.takenToday).length;
    const skipped = medicines.filter(m => m.skippedToday).length;

    let score = 70;
    if (taken === total) {
      score = 98;
    } else if (taken + skipped === total && taken > 0) {
      score = 80;
    } else if (taken > 0) {
      score = 65;
    } else {
      score = 45;
    }

    return {
      score,
      status: score >= 75 ? 'Good' : score >= 50 ? 'Needs Attention' : 'High Attention',
      label: 'Medication Adherence',
      explanation: `${taken}/${total} scheduled medicines marked taken today.`
    };
  }

  private static evaluateNutritionLifestyle(
    profile: HealthProfile | null,
    today: DailyHealthLog | null,
    _history: DailyHealthLog[]
  ): CategoryScore {
    const pattern = profile?.nutritionPattern ?? null;
    const todayMealConsistency = today?.nutritionConsistency ?? null;

    if (!pattern && !todayMealConsistency) {
      return {
        score: null,
        status: 'Not enough data',
        label: 'Nutrition & Lifestyle',
        explanation: 'Nutrition pattern and meal consistency not logged.'
      };
    }

    let score = 65;
    if (pattern === 'balanced' || pattern === 'high_protein' || pattern === 'vegetarian') {
      score = 85;
    } else if (pattern === 'fast_food_frequent' || pattern === 'irregular') {
      score = 52;
    }

    if (todayMealConsistency === 'balanced' || todayMealConsistency === 'regular') {
      score = Math.min(95, score + 10);
    } else if (todayMealConsistency === 'irregular') {
      score = Math.max(40, score - 15);
    }

    return {
      score,
      status: score >= 75 ? 'Good' : score >= 50 ? 'Needs Attention' : 'High Attention',
      label: 'Nutrition & Lifestyle',
      explanation: `Diet pattern: ${pattern || 'standard'}. Meal schedule: ${todayMealConsistency || 'regular'}.`
    };
  }

  private static evaluateGeneralConsistency(history: DailyHealthLog[]): CategoryScore {
    if (history.length === 0) {
      return {
        score: 60,
        status: 'Needs Attention',
        label: 'Wellness Consistency',
        explanation: 'Initial day of health logging. Continuous tracking builds consistency score.'
      };
    }

    const logDays = history.length;
    let score = 50;
    if (logDays >= 7) score = 95;
    else if (logDays >= 5) score = 85;
    else if (logDays >= 3) score = 75;
    else score = 65;

    return {
      score,
      status: score >= 75 ? 'Good' : score >= 50 ? 'Needs Attention' : 'High Attention',
      label: 'Wellness Consistency',
      explanation: `${logDays} days of health records logged.`
    };
  }

  private static generateInsights(
    profile: HealthProfile | null,
    today: DailyHealthLog | null,
    history: DailyHealthLog[],
    medicines: MedicineItem[],
    symptoms: SymptomReport[],
    categoryScores: Record<string, CategoryScore>
  ) {
    const positiveInsights: string[] = [];
    const areasNeedingAttention: string[] = [];
    const personalizedSuggestions: string[] = [];
    const trends: { metric: string; description: string; status: 'improving' | 'steady' | 'declining' }[] = [];

    // Positive insights
    if (categoryScores.sleep.score && categoryScores.sleep.score >= 75) {
      positiveInsights.push('Your sleep duration and quality meet healthy restorative benchmarks.');
    }
    if (categoryScores.hydration.score && categoryScores.hydration.score >= 75) {
      positiveInsights.push('Optimal daily hydration supports your energy metabolism and concentration.');
    }
    if (categoryScores.dailySteps.score && categoryScores.dailySteps.score >= 75) {
      positiveInsights.push('High daily step count demonstrates positive cardiovascular movement habits.');
    }
    if (categoryScores.medicationAdherence.score && categoryScores.medicationAdherence.score >= 80) {
      positiveInsights.push('Consistent medicine adherence according to your prescriptions.');
    }
    if (positiveInsights.length === 0) {
      positiveInsights.push('You have started actively recording your wellness markers with MediMitra.');
    }

    // Areas needing attention
    if (categoryScores.hydration.score && categoryScores.hydration.score < 65) {
      areasNeedingAttention.push('Your hydration intake is below the recommended 2.5L daily target.');
    }
    if (categoryScores.sleep.score && categoryScores.sleep.score < 65) {
      areasNeedingAttention.push('Your sleep duration has been below optimal restorative levels.');
    }
    if (categoryScores.stress.score && categoryScores.stress.score < 60) {
      areasNeedingAttention.push('Recent stress indicators suggest taking brief mindfulness or breathing breaks.');
    }
    if (categoryScores.dailySteps.score && categoryScores.dailySteps.score < 60) {
      areasNeedingAttention.push('Daily step count is low; light walking intervals can boost alertness.');
    }
    if (areasNeedingAttention.length === 0) {
      areasNeedingAttention.push('Maintain your current lifestyle consistency across sleep, water, and activity.');
    }

    // Suggestions
    personalizedSuggestions.push('Keep a water bottle on your desk to ensure steady sips throughout the day.');
    personalizedSuggestions.push('Aim for a consistent bedtime within 30 minutes every evening.');
    if (profile?.typicalStress === 'high' || (today?.stressLevel && today.stressLevel > 6)) {
      personalizedSuggestions.push('Try a 5-minute box-breathing pause before starting demanding work.');
    }
    if (medicines.some(m => !m.takenToday && !m.skippedToday)) {
      personalizedSuggestions.push('Check pending scheduled medicines for today in your Medicine Manager.');
    }

    // Contextual symptom note if any
    if (symptoms.length > 0) {
      const latest = symptoms[0];
      areasNeedingAttention.push(`Recent symptom logged: "${latest.symptoms.join(', ')}". Rest and hydrate while monitoring progression.`);
    }

    // Trends
    trends.push({
      metric: 'Sleep Consistency',
      description: history.length > 2 ? 'Stable sleep routine over recorded period' : 'Initial sleep entries logged',
      status: 'improving',
    });
    trends.push({
      metric: 'Hydration Target',
      description: today && today.waterIntakeLiters >= 2.0 ? 'Trending towards daily 2.5L goal' : 'Hydration requires steady tracking',
      status: today && today.waterIntakeLiters >= 2.0 ? 'improving' : 'steady',
    });
    trends.push({
      metric: 'Physical Movement',
      description: today && today.steps >= 6000 ? 'Active movement logged today' : 'Maintain hourly stretch intervals',
      status: today && today.steps >= 6000 ? 'improving' : 'declining',
    });

    return {
      positiveInsights,
      areasNeedingAttention,
      personalizedSuggestions,
      trends,
    };
  }
}
